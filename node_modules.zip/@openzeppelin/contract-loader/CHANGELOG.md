# Changelog

## 0.3.0 (2019-11-1)
 * Add support to @truffle/contract objects. ([e95e5b](https://github.com/OpenZeppelin/openzeppelin-contract-loader/commit/e95e5b3499ae1cd55821be5073e1e43e52d9f976))
