module.exports = require('./lib/chai');
