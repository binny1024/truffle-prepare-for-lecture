browserify-des
===

[![Build Status](https://travis-ci.org/crypto-browserify/browserify-des.svg)](https://travis-ci.org/crypto-browserify/browserify-des)

DES for browserify
