This is a stub types definition for bignumber.js (https://github.com/MikeMcl/bignumber.js/).
bignumber.js provides its own type definitions, so you don't need @types/bignumber.js installed!