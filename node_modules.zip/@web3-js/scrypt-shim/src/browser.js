module.exports = require('scryptsy');
