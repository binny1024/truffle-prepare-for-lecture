var createECDH = require('crypto').createECDH

module.exports = createECDH || require('./browser')
